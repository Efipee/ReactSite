import React from "react";

const Admin = () => {
  return (
    <>
      <h2>Welcome admin!</h2>
    </>
  );
};

export default Admin;
